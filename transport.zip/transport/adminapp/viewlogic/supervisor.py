from django.shortcuts import render

def create_supervisor(request):
